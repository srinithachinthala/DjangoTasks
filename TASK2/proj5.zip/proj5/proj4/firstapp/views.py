from django.shortcuts import render
from datetime import date
# Create your views here.
def fun1(request):
    d=date.today()
    dct={"dte":d}
    return render(request,'first.html',dct)