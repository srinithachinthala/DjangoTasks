from . import views
from django.urls import path

urlpatterns=[
    path("first",views.fun1),
    path("second",views.fun2)
]