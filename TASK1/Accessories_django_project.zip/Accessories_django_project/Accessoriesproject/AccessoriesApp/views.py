from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request,"first/home.html")
def about_us(request):
    return render(request,"first/about_us.html")
def gallery(request):
    return render(request,"first/gallery.html")
def contact_page(request):
    return render(request,"first/contact.html")
def products(request):
    return render(request,"first/products.html")
def cart(request):
    return render(request,"first/cart.html")




