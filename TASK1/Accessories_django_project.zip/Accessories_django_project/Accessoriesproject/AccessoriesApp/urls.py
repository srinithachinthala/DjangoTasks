from django.urls import path
from . import views

urlpatterns=[
    path('',views.home),
    path("about",views.about_us),
    path("gallery",views.gallery),
    path("contact_page",views.contact_page),
    path("products",views.products),
    path("cart",views.cart),
]